from ra2ce.analyses.direct.damage_calculation.damage_network_events import (
    DamageNetworkEvents,
)
from ra2ce.analyses.direct.damage_calculation.damage_network_return_periods import (
    DamageNetworkReturnPeriods,
)
