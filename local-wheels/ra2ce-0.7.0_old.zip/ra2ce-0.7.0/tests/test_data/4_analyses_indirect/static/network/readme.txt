shapefile of network
shapefile of area of interest (make geojson?)
OSM pbf file
origin-destination files if applicable