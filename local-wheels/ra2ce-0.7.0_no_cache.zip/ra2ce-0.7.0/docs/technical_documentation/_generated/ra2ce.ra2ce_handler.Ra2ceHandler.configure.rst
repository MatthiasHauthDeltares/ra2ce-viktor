﻿ra2ce.ra2ce\_handler.Ra2ceHandler.configure
===========================================

.. currentmodule:: ra2ce.ra2ce_handler

.. automethod:: Ra2ceHandler.configure