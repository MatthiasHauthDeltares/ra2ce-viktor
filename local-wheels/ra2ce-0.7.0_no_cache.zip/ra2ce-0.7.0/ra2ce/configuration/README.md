# Purpose of this module

Configuration module contains the configuration (concrete) classes and related required to run a `Ra2ce` workflow picking up the information configuration instances from the different modules `analyses` and `network`.