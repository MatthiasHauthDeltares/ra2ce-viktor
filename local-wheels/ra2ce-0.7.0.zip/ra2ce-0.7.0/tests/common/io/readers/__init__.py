from tests import test_data

test_data_readers = test_data / "readers_test_data"
