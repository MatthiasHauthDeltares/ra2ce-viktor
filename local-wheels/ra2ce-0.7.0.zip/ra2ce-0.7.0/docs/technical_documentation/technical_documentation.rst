.. automodule:: ra2ce
    :members:

.. _technical_documentation:

Technical Documentation
=======================

Running RA2CE
------------------

.. autosummary::
    :toctree: _generated

    ra2ce.ra2ce_handler.Ra2ceHandler.configure
    ra2ce.ra2ce_handler.Ra2ceHandler.run_analysis

